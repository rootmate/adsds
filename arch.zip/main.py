#modules
import requests
import os
import time
from Header import Parser
import re
from adder import Adder
from colorama import Fore
import json
from Waf import Waf_Detect
from optparse import OptionParser
import subprocess
import sys
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor
#colors
color_off="\033[0m"       # Text Reset

# Regular Colors
black="\033[0;30m"        # Black
red="\033[0;31m"          # Red
green="\033[0;32m"        # Green
yellow="\033[0;33m"       # Yellow
blue="\033[0;34m"         # Blue
purple="\033[0;35m"       # Purple
cyan="\033[0;36m"         # Cyan
white="\033[0;37m"        # White

# Bold
bblack="\033[1;30m"       # Black
bred="\033[1;31m"         # Red
bgreen="\033[1;32m"       # Green
byellow="\033[1;33m"      # Yellow
bblue="\033[1;34m"        # Blue
bpurple="\033[1;35m"      # Purple
bcyan="\033[1;36m"        # Cyan
bwhite="\033[1;37m"       # White

# Underline
ublack="\033[4;30m"       # Black
ured="\033[4;31m"         # Red
ugreen="\033[4;32m"       # Green
uyellow="\033[4;33m"      # Yellow
ublue="\033[4;34m"        # Blue
upurple="\033[4;35m"      # Purple
ucyan="\033[4;36m"        # Cyan
uwhite="\033[4;37m"       # White

# Background
on_black="\033[40m"       # Black
on_red="\033[41m"         # Red
on_green="\033[42m"       # Green
on_yellow="\033[43m"      # Yellow
on_blue="\033[44m"        # Blue
on_purple="\033[45m"      # Purple
on_cyan="\033[46m"        # Cyan
on_white="\033[47m"       # White

# High Intensty
iblack="\033[0;90m"       # Black
ired="\033[0;91m"         # Red
igreen="\033[0;92m"       # Green
iyellow="\033[0;93m"      # Yellow
iblue="\033[0;94m"        # Blue
ipurple="\033[0;95m"      # Purple
icyan="\033[0;96m"        # Cyan
iwhite="\033[0;97m"       # White

# Bold High Intensty
biblack="\033[1;90m"      # Black
bired="\033[1;91m"        # Red
bigreen="\033[1;92m"      # Green
biyellow="\033[1;93m"     # Yellow
biblue="\033[1;94m"       # Blue
bipurple="\033[1;95m"     # Purple
bicyan="\033[1;96m"       # Cyan
biehite="\033[1;97m"      # White

# High Intensty backgrounds
on_iblack="\033[0;100m"   # Black
on_ired="\033[0;101m"     # Red
on_igreen="\033[0;102m"   # Green
on_iyellow="\033[0;103m"  # Yellow
on_iblue="\033[0;104m"    # Blue
on_ipurple="\033[10;95m"  # Purple
on_icyan="\033[0;106m"    # Cyan
on_iwhite="\033[0;107m"   # White
#newcolor
acl='\033[1;30m'
rcl='\033[1;31m'
ycl='\033[1;33m'
ncl='\033[0;00m'
####
###
#logo
def clr():
    os.system("clear")
def logo():
    try:
        import os
        import requests
    except:
        os.system("sudo apt install ruby -y;gem install lolcat;pip3 install requests;pip3 install wafw00f")
        import os
        import requests
    clr()
    os.system("lolcat .lshow.txt")
    print(rcl+"""

 ====================================="""+acl+"""
 [ GITHUB   ] /ogh-bnz
 [ Facebook ] /k.h.r.404
 [ Telegram ] /oghbnz"""+rcl+"""
 =====================================

""")
#install_procc




#opt

logo()
parser = OptionParser()

parser.add_option('--tf', dest='text_filename', help="Mention the text filename/list you'd like to scan, for instance, urls.txt ")
parser.add_option("--ts", dest="target_site", help="Provide the target site you'd like to scan, such as http://pythagoras.com/?id=220")
parser.add_option('--sr', dest='save_results', help="Indicate the desired results filename for storing the output, result.txt")
parser.add_option('--tc', dest='threads_count', help="Specify the desired number of threads count for sending concurrent requests Maximum: 10")
parser.add_option('-H', dest='headers', help="specify Custom Headers")
parser.add_option('--waf', dest='waf',action='store_true', help="Before testing payloads, confirm the presence of a web application firewall")
parser.add_option('-w', dest='custom_waf',help='use specific payloads related to WAF')
parser.add_option('--crawl',dest='crawl',help='crawl then find xss',action="store_true")
parser.add_option('--pipe',dest="pipe",action="store_true",help="pipe output of a process as an input")

val,args = parser.parse_args()
filename = val.text_filename
threads = val.threads_count
output = val.save_results
url = val.target_site
crawl = val.crawl
waf = val.waf
pipe = val.pipe
custom_waf = val.custom_waf
headers = val.headers

try:
    if headers is not None:
        print(ycl + " [+] Metadata: {}".format(headers))
        headers = Parser.headerParser(headers.split(','))
except AttributeError:
    headers = Parser.headerParser(headers.split())


try:
    threads = int(threads)
except TypeError:
    threads = 1
if threads > 10:
    threads = 7

if crawl:
    filename = f"{url.split('://')[1]}_katana"

class Main:

    def __init__(self,url=None, filename=None, output=None,headers=None):
        self.filename = filename
        self.url = url
        self.output = output
        self.headers = headers
        print(headers)
        self.result = []

    def read(self,filename):
        '''
        Read & sort GET  urls from given filename
        '''
        print(+ "Process the URLs")
        urls = subprocess.check_output(f"cat {filename} | grep '=' | sort -u",shell=True).decode('utf-8')
        if not urls:
            print(Fore.GREEN + f"[+] No URLs with GET parameters")
        return urls.split()

    def write(self, output, value):
        '''
        Writes the output back to the given filename.
        '''
        if not output:
            return None
        subprocess.call(f"echo '{value}' >> {output}",shell=True)

    def replace(self,url,param_name,value):
        return re.sub(f"{param_name}=([^&]+)",f"{param_name}={value}",url)
    def bubble_sort(self, arr):
        '''
        For sorting the payloads
        '''
        #print(arr)
        a = 0
        keys = []
        for i in arr:
            for j in i:
                keys.append(j)
        #print(keys)
        while a < len(keys) - 1:
            b = 0
            while b < len(keys) - 1:
                d1 = arr[b]
                #print(d1)
                d2 = arr[b + 1]
               # print(d2)
                if len(d1[keys[b]]) < len(d2[keys[b+1]]):
                    d = d1
                    arr[b] = arr[b+1]
                    arr[b+1] = d
                    z = keys[b+1]
                    keys[b+1] = keys[b]
                    keys[b] = z
                b += 1
            a += 1
        return arr
    
    def crawl(self):
        '''
        Use this method to crawl the links using katana (return type: None)
        '''
        print(Fore.BLUE + "[+] Crawling Links")
        subprocess.check_output(f"katana -u {url} -jc -d 4 -o {url.split('://')[1]}_katana",shell=True)
        print(Fore.BLUE + f"[+] Results Saved As {url.split('://')[1]}_katana")
        return None



    def parameters(self, url):

        '''
        This function will return every parameter in the url as dictionary.
        '''

        param_names = []
        params = urlparse(url).query
        params = params.split("&")
        if len(params) == 1:
            params = params[0].split("=")
            param_names.append(params[0])
            # print("I am here")
        else:
            for param in params:
                param = param.split("=")
                # print(param)
                param_names.append(param[0])
        return param_names

    def parser(self, url, param_name, value):
        '''
        This function will replace the parameter's value with the given value and returns a dictionary
        '''
        final_parameters = {}
        parsed_data = urlparse(url)
        params = parsed_data.query
        protocol = parsed_data.scheme
        hostname = parsed_data.hostname
        path = parsed_data.path
        params = params.split("&")
        if len(params) == 1:
            params = params[0].split("=")
            final_parameters[params[0]] = params[1]
            #print("I am here")
        else:
            for param in params:
                param = param.split("=")
                #print(param)
                final_parameters[param[0]] = param[1]
        #print(final_parameters[param_name] + value)
        final_parameters[param_name] = value
        #print(final_parameters)
        return final_parameters

    def validator(self, arr, param_name, url):
        dic = {param_name: []}
        try:
            for data in arr:
                final_parameters = self.parser(url,param_name,data + "randomstring")
                new_url = urlparse(url).scheme + "://" + urlparse(url).hostname + "/" + urlparse(url).path
                #print(new_url)
                if self.headers:
                    #print("I am here")
                    response = requests.get(new_url,params=final_parameters,headers=self.headers,verify=False).text
                else:
                    response = requests.get(new_url,params=final_parameters,verify=False).text
                if data + "randomstring" in response:
                    if not threads or threads == 1:
                        print(Fore.GREEN + f"[+] {data} is reflecting in the response")
                    dic[param_name].append(data)
        except Exception as e:
            print(e)

        return dic

    def fuzzer(self, url):
        data = []
        dangerous_characters = Adder().dangerous_characters
        parameters = self.parameters(url)
        if '' in parameters and len(parameters) == 1:
            print(ycl)
            print(f"[+] No valid GET parameters found. Exiting")
            exit()
        if not threads or int(threads) == 1:
            print(ycl)
            print(f"[+] {len(parameters)} Parameters identified")
        for parameter in parameters:
            if not threads or threads == 1:
                print(ycl+ f"[+] Testing parameter name: {parameter}")
            out = self.validator(dangerous_characters,parameter,url)
            data.append(out)
        if not threads or threads == 1:
            print(ycl+"[+] Fuzzing has finished execution")
        return self.bubble_sort(data)

    def filter_payload(self,arr,firewall):
        payload_list = []
        size = int(len(arr) / 2)
        if not threads or threads == 1:
            print(ycl+ f"[+] Payloads is being loaded")
        dbs = open(".payloads.json")
        dbs = json.load(dbs)
        #print(dbs)
        new_dbs = []
        #print(firewall)
        if firewall:
            print(ycl + f"[+] Applying payload filters {firewall.upper()}")
            try:
                for i in range(0,len(dbs)):
                    if dbs[i]['waf'] == firewall:
                        #print(1)
                        new_dbs.append(dbs[i])
                    #size = len(dbs)
            except Exception as e:
                print(e)
            if not new_dbs:
                print(rcl + "[+] No matching payloads found for this WAF")
                exit()
        else:
            for i in range(0,len(dbs)):
                if not dbs[i]['waf']:
                    new_dbs.append(dbs[i])
        dbs = new_dbs
        #print(dbs)
        for char in arr:
            for payload in dbs:
                attributes = payload['Attribute']
                if char in attributes:
                    payload['count'] += 1
        #print(dbs)
        def fun(e):
            return e['count']

        #size = int(len(dbs) / 2)
        dbs.sort(key=fun,reverse=True)
        #print(dbs)
        for payload in dbs:
            if payload['count'] == len(arr) and len(payload['Attribute']) == payload['count'] :
                #print(payload)
                if not threads or threads == 1:
                    print(ycl + f"[+] Found ideal payloads for the target site")
                #print(payload['count'],len(payload['Attributes']))
                payload_list.insert(0,payload['Payload'])
                #print(payload_list)
                continue
            if payload['count'] > size:
                payload_list.append(payload['Payload'])
                continue
        return payload_list


    def scanner(self,url):
        print(ycl + f"[+] Testing in progress {url}")
        if waf:
            print(ycl + "[+] Analyzing for WAF protection")
            firewall = Waf_Detect(url).waf_detect()
            if firewall:
                print(ycl + f"[+] {firewall.upper()} Successfully detected")
            else:
                print(ycl + f"[+] No WAF detected. Switching to normal payloads")
                firewall = None
        elif custom_waf:
            #print(1)
            firewall = custom_waf
        else:
            firewall = None
        out = self.fuzzer(url)
       # print(out)
        for data in out:
            for key in data:
                payload_list = self.filter_payload(data[key],firewall)
                #print(f"[+] TESTING THE BELOW PAYLOADS {payload_list}")
            for payload in payload_list:
                try:
                    #print(f"Testing: {payload}")
                    data = self.parser(url,key,payload)
                    parsed_data = urlparse(url)
                    new_url = parsed_data.scheme +  "://" + parsed_data.netloc + parsed_data.path
                    #print(new_url)
                    #print(data)
                    if self.headers:
                        #print("I am here")
                        response = requests.get(new_url,params=data, headers=self.headers,verify=False).text
                    else:
                        response = requests.get(new_url, params=data,verify=False).text
                    if payload in response:
                        print(bgreen + f"[+] Vuln: {url}\nParameter: {key}\Applied the provided payload: {payload}")
                        print(self.replace(url,key,payload))
                        self.result.append(self.replace(url,key,payload))
                        return True
                except Exception as e:
                    print(e)
        if not threads or threads == 1:
            print(rcl + f"[+] No vulnerabilities detected on the target")
        return None



logo()
#mt
import sys
from concurrent.futures import ThreadPoolExecutor

def main_function(filename, output, headers=None, url=None, crawl=False, pipe=False, threads=5):
    urls = []
    Scanner = Main(filename, output, headers=headers)
    try:
        if url and not filename:
            Scanner = Main(url, output, headers=headers)
            Scanner.scanner(url)
            if Scanner.result:
                Scanner.write(output, Scanner.result[0])
            exit()
        elif filename and crawl:
            Scanner.crawl()
            urls = Scanner.read(filename)
        elif pipe:
            out = sys.stdin
            for url in out:
                urls.append(url)
        else:
            urls = Scanner.read(filename)
        print(ycl + "[+] Current Threads: {}".format(threads))

        with ThreadPoolExecutor(max_workers=threads) as executor:
            executor.map(Scanner.scanner, urls)

        for i in Scanner.result:
            Scanner.write(output, i)
        print(ycl + "[+] Finished")
    except Exception as e:
        print(e)




if __name__ == "__main__":
    logo()
    main_function(filename, output, headers=headers, url=url, crawl=crawl, pipe=pipe, threads=threads)
